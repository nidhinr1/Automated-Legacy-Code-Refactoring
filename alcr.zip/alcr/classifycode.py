import pandas as pd
import pickle

# ------------------------------------------------------------------------------
# 1️⃣ Load PMD report CSV
# ------------------------------------------------------------------------------


def classify():
    report_file="pmd_report.csv"
    print(f"Loading PMD report: {report_file}")
    report = pd.read_csv(report_file)

    # ------------------------------------------------------------------------------
    # 2️⃣ Aggregate features (as used in your training)
    # ------------------------------------------------------------------------------
    # Count number of violations per file and Rule set
    features_df = report.groupby(['File', 'Rule set']).size().reset_index(name='Problem')

    # ------------------------------------------------------------------------------
    # 3️⃣ Load trained classifier pipeline
    # ------------------------------------------------------------------------------
    model_file = r"D:/project/alcr/classifier_model.pkl"
    print(f"Loading trained classifier: {model_file}")

    with open(model_file, "rb") as f:
        classifier = pickle.load(f)

    # ------------------------------------------------------------------------------
    # 4️⃣ Perform Classification
    # ------------------------------------------------------------------------------
    print("Performing classification...")
    X_new = features_df.copy()
    y_pred = classifier.predict(X_new)
    y_labels = ['Good' if pred == 1 else 'Bad' for pred in y_pred]

    # ------------------------------------------------------------------------------
    # 5️⃣ Display results directly in terminal
    # ------------------------------------------------------------------------------
    X_new['Predicted_Quality'] = y_labels

    print("\nClassification results:")
    print(X_new.to_string(index=False))

    # ------------------------------------------------------------------------------
    # 6️⃣ Determine Overall File Quality
    # ------------------------------------------------------------------------------
    # If majority is Good -> Overall Good
    # Otherwise -> Overall Bad
    overall = X_new.groupby('File')['Predicted_Quality'].apply(
        lambda x: 'Good' if (x.value_counts().get('Good', 0) >= x.value_counts().get('Bad', 0)) else 'Bad'
        ).reset_index()

    print("\nOverall code quality:")
    print(overall.to_string(index=False))