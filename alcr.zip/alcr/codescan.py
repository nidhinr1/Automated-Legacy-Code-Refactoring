import subprocess


def scanjava(java_file):
    # Define command components
    pmd_cmd = "pmd.bat"  # or pmd if it's in your PATH
    ruleset_file = r"D:/project/alcr/pmd-ruleset.xml"
    report_file = "pmd_report.csv"

    # Run pmd check command
    try:
        subprocess.run(
            [pmd_cmd, "check","-d", java_file,"-R", ruleset_file,"-f", "csv","-r", report_file],
            check=True,
            shell=True
        )
        print(f"PMD analysis completed. Report generated in {report_file}.")
    except subprocess.CalledProcessError as e:
        if e.returncode == 4:
            print(f"Report generated in {report_file}.")
        else:
            print("Error while running PMD:")
            print(e)
