import subprocess
import autopep8
import os
import re

def run_pylint(file_path):
    result = subprocess.run(
        ["pylint", file_path, "--disable=all", "--enable=C,R,W"],
        capture_output=True,
        text=True
    )
    return result.stdout

def extract_quality_score(pylint_output):
    match = re.search(r"rated at ([\d.]+)/10", pylint_output)
    return float(match.group(1)) if match else None

def apply_autopep8(code):
    return autopep8.fix_code(code)

def read_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

def write_file(file_path, content):
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)

def refactor_code(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError("❌ File not found.")

    max_attempts = 100
    target_score = 7.0

    for attempt in range(1, max_attempts + 1):
        print(f"\n🔁 Refactoring attempt {attempt} of {max_attempts}...")
        print("📥 Reading file...")
        code = read_file(file_path)

        print("🔧 Applying autopep8 formatting...")
        formatted_code = apply_autopep8(code)
        write_file(file_path, formatted_code)
        print(f"✅ Code formatted and updated in-place: {file_path}")

        print("🔍 Running pylint for code quality:")
        pylint_output = run_pylint(file_path)
        print(pylint_output)

        score = extract_quality_score(pylint_output)
        if score is not None:
            print(f"📊 Code Quality Score: {score}/10")
            if score >= target_score:
                print("🎉 Code quality target achieved! Stopping refactoring.")
                break
            else:
                print("⚠️ Code quality below target. Continuing refactoring...")
        else:
            print("⚠️ Could not extract code quality score.")
            break  # Stop if pylint fails to give a score

    return file_path
