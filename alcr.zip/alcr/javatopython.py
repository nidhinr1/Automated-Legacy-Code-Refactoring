import os
import re
from langchain.llms import Ollama
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

def clean_llm_output(output: str) -> str:
    """
    Removes markdown formatting, explanations, and ensures Python-only code.
    """
    lines = output.splitlines()
    code_lines = []
    found_code = False

    for line in lines:
        line_strip = line.strip()

        # Skip markdown code block markers
        if line_strip.startswith("```"):
            continue

        # Stop at obvious explanation
        if found_code and not line_strip.startswith((
            "import", "def", "class", "if", "for", "while", "return", "print", "input", "self", "from", "#"
        )) and line_strip and not re.match(r"^\s", line):  # likely natural language
            break

        if line_strip:
            found_code = True

        code_lines.append(line)

    code = "\n".join(code_lines)

    # Fix dangling if __name__ block
    code = re.sub(
        r'(if\s+__name__\s*==\s*[\'"]__main__[\'"]\s*:\s*)$',
        r'\1\n    pass',
        code,
        flags=re.MULTILINE
    )

    return code

def convert_java_to_python(java_file_path):
    if not os.path.isfile(java_file_path):
        raise FileNotFoundError(f"File '{java_file_path}' not found.")

    with open(java_file_path, 'r', encoding='utf-8') as file:
        java_code = file.read()

    llm = Ollama(model="qwen2.5-coder:0.5b")

    prompt = PromptTemplate(
        input_variables=["java_code"],
        template="""
Convert the following Java code into clean Python.

Return ONLY executable Python code — NO explanations, NO markdown, NO comments.

Java Code:
{java_code}

Python Code:
"""
    )

    chain = LLMChain(llm=llm, prompt=prompt)
    raw_output = chain.run(java_code=java_code)

    clean_code = clean_llm_output(raw_output)

    base_name = os.path.splitext(java_file_path)[0]
    python_file_path = base_name + ".py"

    with open(python_file_path, 'w', encoding='utf-8') as file:
        file.write(clean_code)

    print(f"✅ Clean Python code saved to: {python_file_path}")
    return python_file_path
